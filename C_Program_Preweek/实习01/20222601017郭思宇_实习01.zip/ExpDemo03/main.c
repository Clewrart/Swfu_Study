#include <stdio.h>
#include <stdlib.h>
#include "node.h"

typedef struct Data
{
    int* arr;  // һά����
    int n;     // һά�����Ԫ�ظ���
} Data;

// ���ļ���ȡ���ݲ���������������
void read_data(const char* filename, Data* data1, Data* data2);

// �ϲ�����������
NODE* merge(NODE* h1, NODE* h2);

// ��������������д���ļ�
void write_data(const char* filename, NODE* head);

int main()
{
    const char* input_filename = "input.txt";
    const char* output_filename = "output.txt";

    Data data1 = { NULL };
    Data data2 = { NULL };

    read_data(input_filename, &data1, &data2);

    NODE* h1 = createList(data1.arr, data1.n);
    outputList(h1);

    NODE* h2 = createList(data2.arr, data2.n);
    outputList(h2);

    NODE* h3 = merge(h1, h2);
    outputList(h3);

    write_data(output_filename, h3);

    deleteList(h3);
    deleteList(h2);
    deleteList(h1);

    return 0;
}

void read_data(const char* filename, Data* data1, Data* data2)
{
    FILE* fp = fopen(filename, "r");
    int n1, n2;
    fscanf(fp, "%d", &n1);
    data1->n = n1;
    data1->arr = (int*)malloc(data1->n * sizeof(int));

    for (int i = 0; i < data1->n; i++)
    {
        fscanf(fp, "%d", &data1->arr[i]);
    }

    fscanf(fp, "%d", &n2);
    data2->n = n2;
    data2->arr = (int*)malloc(data2->n * sizeof(int));

    for (int i = 0; i < data2->n; i++)
    {
        fscanf(fp, "%d", &data2->arr[i]);
    }

    fclose(fp);
}

NODE* merge(NODE* h1, NODE* h2)
{
    NODE *head,*linshi,*h3;

    head=(NODE*)malloc(sizeof(NODE));

    linshi=head;
    NODE* linshi_1 = h1->next;
    NODE* linshi_2 = h2->next;

    for ( int i1 = 0; linshi_1 != NULL && linshi_2 != NULL;i1++ )
    {
        NODE* h3 = (NODE*)malloc(sizeof(NODE));
        if (linshi_1->data > linshi_2->data)
        {
            h3->data = linshi_2->data;
            h3->next = NULL;

            linshi_2 = linshi_2->next;
            linshi->next = h3;

            linshi = linshi->next;
        }
        else
        {
            h3->data = linshi_1->data;
            h3->next = NULL;

            linshi_1 = linshi_1->next;
            linshi->next = h3;

            linshi = linshi->next;
        }
    }
    if (linshi_1 != NULL)
    {
        for ( int i2 = 0; linshi_1 != NULL;i2++ )
        {
            NODE* h3 = (NODE*)malloc(sizeof(NODE));
            h3->data = linshi_1->data;
            h3->next = NULL;
            linshi_1 = linshi_1->next;
            linshi->next = h3;
            linshi = linshi->next;
        }
    }
    if (linshi_2 != NULL)
    {
        for (int i3 =0; linshi_2 != NULL;i3++)
        {
            NODE* h3 = (NODE*)malloc(sizeof(NODE));
            h3->data = linshi_2->data;
            h3->next = NULL;
            linshi_2 = linshi_2->next;
            linshi->next = h3;
            linshi = linshi->next;
        }
    }

    return head;
}


void write_data(const char* filename, NODE* head)
{

    FILE* fp2 = fopen(filename, "w");

    // ����ڵ���
    int count = 0;
    NODE* current = head;
    while (current != NULL)
    {
        if (current->data != 0)
        {
            count++;
        }
        current = current->next;
    }

    fprintf(fp2, "%d\n", count);




    // д��ڵ�����
    current = head;
    while (current != NULL)
    {
        if (current->data != 0)
        {
            fprintf(fp2, "%d ", current->data);
        }
        current = current->next;
    }
    fclose(fp2);
}
